
public enum Direction 
{
   forward,
   right,
   back,
   left
}
